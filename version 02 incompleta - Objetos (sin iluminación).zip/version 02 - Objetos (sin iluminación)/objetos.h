struct OBJETO {
  COLOR color;
  PUNTO3D centro;
  float radio;
  struct OBJETO *sig;
};



